# Loan EMI Explorer - Summary Report
_Generated 2026-11-25 07:44_

## Key metrics

| Metric | Value |
|---|---|
| Loans recorded | 43 |
| Total principal | ₹14,96,92,000.00 |
| Total interest | ₹16,54,36,011.60 |
| Total payable | ₹31,51,28,011.60 |
| Combined monthly EMI | ₹20,67,236.74 |
| Average EMI | ₹48,075.27 |
| Average rate | 12.60% |
| Average tenure | 79 months |
| Flagged records | 19 |

## By category

| Category | Loans | Principal | Total EMI |
|---|---|---|---|
| Business | 10 | ₹11,63,19,000.00 | ₹14,24,833.71 |
| Car | 6 | ₹69,10,000.00 | ₹1,61,721.19 |
| Education | 3 | ₹34,30,000.00 | ₹76,356.33 |
| Gold | 6 | ₹12,68,000.00 | ₹1,20,059.52 |
| Home | 6 | ₹1,92,57,000.00 | ₹1,79,293.93 |
| Personal | 12 | ₹25,08,000.00 | ₹1,04,972.06 |

## All records

| ID | Name | Category | Amount | Rate | Months | EMI |
|---|---|---|---|---|---|---|
| 6778761b | T | Car | ₹5,00,000.00 | 9% | 60 | ₹10,379.18 |
| 0a31eb43 | Business loan - Arjun | Business | ₹24,63,000.00 | 14.76% | 24 | ₹1,19,141.96 |
| c884a9e5 | Longest tenure (40 yrs) | Home | ₹30,00,000.00 | 8.5% | 480 | ₹21,992.82 |
| 127a7464 | Shortest tenure (1 month) | Gold | ₹50,000.00 | 11% | 1 | ₹50,458.33 |
| 3e6af81b | Car loan - Suresh | Car | ₹15,17,000.00 | 10.18% | 78 | ₹26,667.28 |
| 2b7c5158 | Gold loan - Arjun | Gold | ₹1,02,000.00 | 12% | 6 | ₹17,599.93 |
| 84c93d0a | Personal loan - Arjun | Personal | ₹4,23,000.00 | 14.14% | 12 | ₹38,007.82 |
| 7e2d76ee | Maximum loan | Business | ₹10,00,00,000.00 | 9.5% | 240 | ₹9,32,131.19 |
| 90decd74 | Home loan - Priya | Home | ₹19,21,000.00 | 9.55% | 252 | ₹17,687.55 |
| 3e99ccd1 | Gold loan - Imran | Gold | ₹3,77,000.00 | 9.69% | 30 | ₹14,200.62 |
| 7b216130 | Personal loan - Imran | Personal | ₹1,79,000.00 | 17.18% | 48 | ₹5,181.74 |
| d2c8232e | Business loan - Karthik | Business | ₹27,16,000.00 | 11.98% | 42 | ₹79,486.31 |
| faceb625 | Business loan - Imran | Business | ₹8,43,000.00 | 12.5% | 42 | ₹24,883.90 |
| d31b9cc5 | Interest > principal home loan | Home | ₹50,00,000.00 | 12% | 360 | ₹51,430.63 |
| 46be83a5 | Business loan - Meena | Business | ₹18,43,000.00 | 12.03% | 72 | ₹36,059.76 |
| f75f23cb | Personal loan - Arjun | Personal | ₹1,36,000.00 | 14.55% | 42 | ₹4,151.45 |
| b36c467a | High-rate business loan | Business | ₹8,00,000.00 | 24% | 48 | ₹26,081.47 |
| a7e54eac | Business loan - Arjun | Business | ₹15,73,000.00 | 16.76% | 42 | ₹49,758.63 |
| e803590b | Personal loan - Suresh | Personal | ₹3,98,000.00 | 11.66% | 48 | ₹10,414.55 |
| 651bc346 | Personal loan - Meena | Personal | ₹60,000.00 | 11.35% | 30 | ₹2,306.53 |
| c2e0ba1a | Gold loan - Divya | Gold | ₹3,37,000.00 | 10.06% | 18 | ₹20,248.55 |
| 5d7ae7ed | Home loan - Arjun | Home | ₹46,22,000.00 | 9.11% | 210 | ₹44,097.17 |
| 2db1ba99 | Gold loan - Suresh | Gold | ₹2,41,000.00 | 10.35% | 36 | ₹7,816.05 |
| 590e52db | Education loan - Meena | Education | ₹2,22,000.00 | 11.54% | 66 | ₹4,558.87 |
| a2542606 | Education loan - Karthik | Education | ₹21,87,000.00 | 10.72% | 60 | ₹47,245.86 |
| 1f1f402b | Car loan - Priya | Car | ₹14,13,000.00 | 9.45% | 48 | ₹35,465.26 |
| d215f514 | Max rate payday loan | Personal | ₹25,000.00 | 50% | 6 | ₹4,794.96 |
| 10ade441 | Business loan - Priya | Business | ₹13,43,000.00 | 14.16% | 42 | ₹40,736.23 |
| 73816615 | Over-stretched EMI | Car | ₹15,00,000.00 | 12% | 36 | ₹49,821.46 |
| c8fd2042 | Car loan - Arjun | Car | ₹12,80,000.00 | 9.26% | 66 | ₹24,823.16 |
| fb583a29 | Home loan - Imran | Home | ₹22,14,000.00 | 9.07% | 180 | ₹22,548.15 |
| bfe364ed | Minimum loan | Personal | ₹1,000.00 | 10% | 1 | ₹1,008.33 |
| fe3349bc | Education loan - Suresh | Education | ₹10,21,000.00 | 11.98% | 54 | ₹24,551.60 |
| 0a9856cb | Business loan - Ravi | Business | ₹27,24,000.00 | 14.41% | 48 | ₹74,998.77 |
| 80e7e60a | Personal loan - Anita | Personal | ₹5,58,000.00 | 11.14% | 48 | ₹14,459.77 |
| 36609a53 | Gold loan - Karthik | Gold | ₹1,61,000.00 | 10.9% | 18 | ₹9,736.04 |
| 3007446f | Personal loan - Lakshmi | Personal | ₹2,27,000.00 | 17.51% | 42 | ₹7,267.17 |
| ad7185b0 | Personal loan - Meena | Personal | ₹1,02,000.00 | 12.13% | 36 | ₹3,394.20 |
| 296ec76a | Business loan - Suresh | Business | ₹20,14,000.00 | 15.88% | 78 | ₹41,555.49 |
| 2016848b | Zero interest festival loan | Personal | ₹60,000.00 | 0% | 12 | ₹5,000.00 |
| 0f43537d | Personal loan - Anita | Personal | ₹3,39,000.00 | 12.35% | 48 | ₹8,985.54 |
| 536a269a | Legacy home loan | Home | ₹25,00,000.00 | 8.4% | 240 | ₹21,537.61 |
| 6b9b6b0e | Legacy car loan | Car | ₹7,00,000.00 | 9.1% | 60 | ₹14,564.85 |

## Warnings

- **Business loan - Arjun** (0a31eb43): EMI is 140% of income (limit 50%)
- **Longest tenure (40 yrs)** (c884a9e5): Very long tenure (480 months); Total interest exceeds the amount borrowed
- **Car loan - Suresh** (3e6af81b): EMI is 67% of income (limit 50%)
- **Maximum loan** (7e2d76ee): Total interest exceeds the amount borrowed; Unusually large loan amount
- **Home loan - Priya** (90decd74): Total interest exceeds the amount borrowed
- **Interest > principal home loan** (d31b9cc5): Total interest exceeds the amount borrowed
- **Business loan - Meena** (46be83a5): EMI is 90% of income (limit 50%)
- **High-rate business loan** (b36c467a): High interest rate (24% > 20%)
- **Business loan - Arjun** (a7e54eac): EMI is 124% of income (limit 50%)
- **Gold loan - Divya** (c2e0ba1a): EMI is 51% of income (limit 50%)
- **Home loan - Arjun** (5d7ae7ed): Total interest exceeds the amount borrowed
- **Education loan - Karthik** (a2542606): EMI is 79% of income (limit 50%)
- **Car loan - Priya** (1f1f402b): EMI is 59% of income (limit 50%)
- **Max rate payday loan** (d215f514): High interest rate (50% > 20%)
- **Over-stretched EMI** (73816615): EMI is 125% of income (limit 50%)
- **Home loan - Imran** (fb583a29): EMI is 56% of income (limit 50%)
- **Business loan - Suresh** (296ec76a): EMI is 69% of income (limit 50%)
- **Zero interest festival loan** (2016848b): Zero-interest loan (verify entry)
- **Legacy home loan** (536a269a): Total interest exceeds the amount borrowed
