# Simple Loan EMI Explorer

Python 3.10+ | Terminal app + Streamlit web UI | JSON persistence | Matplotlib charts

## Setup
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
python generate_sample_data.py    # creates 40 sample loans + a messy CSV for import demos
```

## Run
```bash
python cli.py            # terminal menu
streamlit run app.py     # web interface (http://localhost:8501)
```
Both interfaces share `emi_core.py` and the same `data/loans.json`, so data entered in one shows up in the other.

## EMI formula
`EMI = P·r·(1+r)^n / ((1+r)^n − 1)`, with `r = annual rate / 12 / 100`, `n = months`. At 0 % the EMI is `P / n`.

## Validation limits
| Field | Range |
|---|---|
| Loan amount | ₹1,000 – ₹10,00,00,000 |
| Interest rate | 0 – 50 % |
| Tenure | 1 – 480 months |

## Threshold warnings
Rate > 20 %, tenure > 30 years, interest > principal, amount ≥ ₹5 crore, EMI > 50 % of income, 0 % loans.

## Demo script
1. `python cli.py` → option 10 (load sample data) → option 4 (summary).
2. Option 1: enter `abc` as amount, then `-5` as rate, then valid values. Validation catches each mistake.
3. Option 6 (charts) and 7 (export) write to `exports/`.
4. Exit and relaunch: the loans are still there.
5. Option 8 with `sample_data/sample_messy_import.csv` shows row-by-row error logging.
6. `streamlit run app.py` for the web UI.

## Files
| File | Purpose |
|---|---|
| `emi_core.py` | EMI maths, validation, storage, search, analytics, charts, export, import |
| `cli.py` | Terminal menu interface |
| `app.py` | Streamlit web interface |
| `generate_sample_data.py` | Builds sample CSV/JSON datasets |

## FastHTML web interface
```bash
pip install -r requirements_fasthtml.txt
python generate_sample_data.py
python app_fasthtml.py          # http://localhost:5001
```
Pages: Calculator (live HTMX results, save), Records (search, filter, pagination, delete),
Analytics (summary cards, charts, warnings), Import / Export (CSV upload with row errors, MD/TXT/CSV download).
